//Nicolas Slaiman, Pablo Cantero, Maykel Tvihaug y Nicolas Toledo//
//Trabajo Final Capacitacion dia viernes//

//servicio rest//
package main

import (
	"crypto/tls"
	"fmt"
	"net/smtp"
)

func main() {

	var username string
	fmt.Println("Enter username smtp: ")
	fmt.Scanln(&username)

	var pass string
	fmt.Println("Ponga su password smpt: ")
	fmt.Scanln(&pass)

	var email string
	fmt.Println("ponga su email smpt: ")
	fmt.Scanln(&email)

	auth := smtp.PlainAuth("",
		email,
		pass,
		"smpt.gmail.com")

	c, err := smtp.Dial("smpt.gmail.com:587")
	if err != nil {
		panic(err)
	}
	defer c.Close()
	config := &tls.Config{ServerName: "smpt.gmail.com"}

	if err = c.StartTLS(config); err != nil {
		panic(err)
	}

	if err = c.Auth(auth); err != nil {
		panic(err)
	}

	if err = c.Mail(email); err != nil {
		panic(err)
	}
	if err = c.Rcpt(email); err != nil {
		panic(err)
	}

	w, err := c.Data()
	if err != nil {
		panic(err)
	}

	msg := []byte("Lista de dados de alta")
	if _, err := w.Write(msg); err != nil {
		panic(err)
	}

	err = w.Close()
	if err != nil {
		panic(err)
	}
	err = c.Quit()

	if err != nil {
		panic(err)
	}

}

router.POST("/users", func(c *gin.Context) {
	var u srv.User
	if err := c.ShouldBindJSON(&u); err != nil {
	c.String(http.StatusBadRequest, "error al crear el user")
	}
	u = srv.Add(u)
	c.JSON(http.StatusCreated, u)
	
	})

	if err := c.ShouldBindJSON(&u); err != nil
	if err := c.ShouldBindJSON(&u); err != nil {
		c.String(http.StatusBadRequest, "error al crear el user")
		}
		router.Run()
